<template>
  <div></div>
</template>

<script>
// import axios from 'axios'

// const SERVER_URL = process.env.VUE_APP_SERVER_URL

export default {
  name: 'Singup',
  data: function () {
    return {}
  },
  methods: {
    signup: function () {
      
    }
  }
}
</script>