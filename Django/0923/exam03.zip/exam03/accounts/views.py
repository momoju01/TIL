from django.shortcuts import render, redirect
# Create your views here.

def signup(request):
    # Q1-1
    pass

def login(request):
    # Q2-1
    pass
